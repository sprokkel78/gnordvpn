#!/bin/sh
#
# THIS SCRIPT WILL REMOVE THE GNORDVPN APP SYSTEM WIDE
# THE SCRIPT MUST BE RUN WITH SUDO
#
# This will remove the gnordvpn app system wide.
#

rm -rf /usr/share/gnordvpn-sprokkel78
rm /usr/bin/gnordvpn
rm /usr/share/applications/gnordvpn.desktop
