# gnordvpn

A graphical user interface for using the nordvpn client binary on ubuntu and other linux distro's.
It requires Python3.10 and PyGObject.

