GNORDVPN-SPROKKEL78
-------------------

A graphical user interface in PyGTK for using the nordvpn client binary on Ubuntu and other Linux distro's. 
It requires Python3.10, Pip and PyGTK. 

1. $sudo apt install python3 python3-dev
2. $sudo apt install python3-pip
3. $sudo apt install python3-gi python3-gi-cairo gir1.2 gtk-3.0
4. $pip install gnordvpn-sprokkel78


