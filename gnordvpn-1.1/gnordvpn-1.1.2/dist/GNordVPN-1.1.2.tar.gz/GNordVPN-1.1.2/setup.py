from setuptools import setup

setup(
    name='GNordVPN',
    version='1.1.2',
    packages=['GNordVPN'],
    install_requires=[
        'PyGObject',  # Add any dependencies here
    ],
    entry_points={
        'console_scripts': [
            'myapp = gnordvpn:main',  # Replace with your main script
        ],
    },
)




