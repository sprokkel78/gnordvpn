# gnordvpn

A graphical user interface for the nordvpn client binary. 2023
It requires Python3.10 and PyGObject.

