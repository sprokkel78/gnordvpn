# gnordvpn

A graphical user interface in pygtk for using the nordvpn client binary on ubuntu and other linux distro's. 
It requires Python3.10 and PyGTK. 

1. $sudo apt install python3
2. $sudo apt install python3-pip
3. $sudo apt install python3-gi python3-gi-cairo gir1.2 gtk-3.0
4. $pip install gnordvpn-sprokkel78
5. done.

